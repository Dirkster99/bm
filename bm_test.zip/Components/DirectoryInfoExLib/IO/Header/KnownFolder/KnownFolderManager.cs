﻿namespace DirectoryInfoExLib.IO.Header.KnownFolder
{
    using System;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Initializes a new instance of the specified System.Runtime.InteropServices.ComImportAttribute.
    /// </summary>
    [ComImport, Guid("4df0c730-df9d-4ae3-9153-aa6b82e9795a")]
    public class KnownFolderManager
    {
    }
}
