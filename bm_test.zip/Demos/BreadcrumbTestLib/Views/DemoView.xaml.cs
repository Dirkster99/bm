﻿namespace BreadcrumbTestLib.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for DemoView.xaml
    /// </summary>
    public partial class DemoView : UserControl
    {
        public DemoView()
        {
            InitializeComponent();
        }
    }
}
