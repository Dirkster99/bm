﻿namespace BreadcrumbTestLib.Views
{
    using System.Windows.Controls;

    /// <summary>
    /// Interaction logic for DiskTestview.xaml
    /// </summary>
    public partial class DiskTestView : UserControl
    {
        public DiskTestView()
        {
            InitializeComponent();
        }
    }
}
