WatermarkControlsLib

WPF/MVVM control to implement a textbox and combobox with a watermark (a faded label inside the text editing area).

See GitHub for more screenshots and details
https://github.com/Dirkster99/WatermarkControlsLib/blob/master/README.md